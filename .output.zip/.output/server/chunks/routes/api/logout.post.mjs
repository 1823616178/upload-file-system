import { c as defineEventHandler, h as setCookie } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const logout_post = defineEventHandler((event) => {
  setCookie(event, "auth-token", "", {
    httpOnly: false,
    path: "/",
    sameSite: "strict",
    expires: /* @__PURE__ */ new Date(0)
  });
  return { message: "Logout successful" };
});

export { logout_post as default };
//# sourceMappingURL=logout.post.mjs.map
