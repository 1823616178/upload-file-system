import { c as defineEventHandler, r as readBody, h as setCookie } from '../../_/nitro.mjs';
import { p as prisma } from '../../_/db.mjs';
import require$$1 from 'crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@prisma/client';

function verifyPassword(password, storedHash) {
  return new Promise((resolve, reject) => {
    const [salt, key] = storedHash.split(":");
    require$$1.scrypt(password, salt, 64, (err, derivedKey) => {
      if (err) reject(err);
      resolve(key === derivedKey.toString("hex"));
    });
  });
}
const login_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { username, password } = body;
  if (!username || !password) {
    event.res.statusCode = 400;
    return { message: "\u8BF7\u8F93\u5165\u7528\u6237\u540D\u548C\u5BC6\u7801" };
  }
  try {
    const user = await prisma.user.findUnique({
      where: { username }
    });
    if (!user) {
      event.res.statusCode = 401;
      return { message: "\u7528\u6237\u540D\u6216\u5BC6\u7801\u9519\u8BEF" };
    }
    const isValid = await verifyPassword(password, user.password);
    if (isValid) {
      setCookie(event, "auth-token", "valid-session-token", {
        httpOnly: false,
        path: "/",
        sameSite: "strict",
        maxAge: 60 * 60 * 24 * 7
        // 7 days
      });
      return { message: "\u767B\u5F55\u6210\u529F" };
    } else {
      event.res.statusCode = 401;
      return { message: "\u7528\u6237\u540D\u6216\u5BC6\u7801\u9519\u8BEF" };
    }
  } catch (error) {
    console.error("Login error:", error);
    event.res.statusCode = 500;
    return { message: "\u670D\u52A1\u5668\u5185\u90E8\u9519\u8BEF" };
  }
});

export { login_post as default };
//# sourceMappingURL=login.post.mjs.map
