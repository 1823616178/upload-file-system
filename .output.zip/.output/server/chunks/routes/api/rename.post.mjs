import { c as defineEventHandler, r as readBody } from '../../_/nitro.mjs';
import { Client } from 'basic-ftp';
import { p as prisma } from '../../_/db.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@prisma/client';

const rename_post = defineEventHandler(async (event) => {
  try {
    const body = await readBody(event);
    const { id, oldName, newName, source, remotePath } = body;
    if (!newName || !newName.trim()) {
      throw new Error("\u65B0\u6587\u4EF6\u540D\u4E0D\u80FD\u4E3A\u7A7A");
    }
    if (/[<>:"/\\|?*]/.test(newName)) {
      throw new Error("\u6587\u4EF6\u540D\u5305\u542B\u975E\u6CD5\u5B57\u7B26");
    }
    const oldExt = oldName.substring(oldName.lastIndexOf("."));
    const newExt = newName.substring(newName.lastIndexOf("."));
    let finalNewName = newName;
    if (oldExt && newExt !== oldExt) {
      if (!newName.includes(".")) {
        finalNewName = newName + oldExt;
      }
    }
    if (source === "ftp") {
      const client = new Client();
      try {
        await client.access({
          host: "192.168.1.166",
          user: "userftp",
          password: "550312171",
          port: 21,
          secure: false
        });
        const dir = remotePath.substring(0, remotePath.lastIndexOf("/"));
        const newRemotePath = `${dir}/${finalNewName}`;
        const list = await client.list(dir);
        if (list.some((f) => f.name === finalNewName)) {
          throw new Error("\u6587\u4EF6\u540D\u5DF2\u5B58\u5728");
        }
        await client.rename(remotePath, newRemotePath);
        try {
          await prisma.uploadHistory.updateMany({
            where: { remotePath },
            data: {
              fileName: finalNewName,
              remotePath: newRemotePath
            }
          });
        } catch (e) {
          console.warn("\u5173\u8054\u6570\u636E\u5E93\u66F4\u65B0\u5931\u8D25", e);
        }
        return { success: true, newName: finalNewName, newRemotePath };
      } catch (err) {
        throw new Error(`FTP\u91CD\u547D\u540D\u5931\u8D25: ${err.message}`);
      } finally {
        client.close();
      }
    } else {
      const exist = await prisma.uploadHistory.findFirst({
        where: { fileName: finalNewName }
      });
      if (exist) {
        throw new Error("\u6587\u4EF6\u540D\u5DF2\u5B58\u5728");
      }
      await prisma.uploadHistory.update({
        where: { id: BigInt(id) },
        data: { fileName: finalNewName }
      });
      return { success: true, newName: finalNewName };
    }
  } catch (error) {
    return { success: false, error: error.message };
  }
});

export { rename_post as default };
//# sourceMappingURL=rename.post.mjs.map
