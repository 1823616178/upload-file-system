import { c as defineEventHandler, g as getQuery, e as createError, f as setHeader } from '../../_/nitro.mjs';
import { Client } from 'basic-ftp';
import { Writable } from 'stream';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const ftpImage_get = defineEventHandler(async (event) => {
  var _a;
  const query = getQuery(event);
  const filePath = query.path;
  if (!filePath) {
    throw createError({
      statusCode: 400,
      statusMessage: "\u9700\u8981\u6587\u4EF6\u8DEF\u5F84\u53C2\u6570 (path)"
    });
  }
  const client = new Client();
  try {
    await client.access({
      host: "192.168.1.166",
      user: "userftp",
      password: "550312171",
      port: 21,
      secure: false
    });
    const chunks = [];
    const writable = new Writable({
      write(chunk, encoding, callback) {
        chunks.push(Buffer.from(chunk));
        callback();
      }
    });
    await client.downloadTo(writable, filePath);
    const buffer = Buffer.concat(chunks);
    const ext = (_a = filePath.split(".").pop()) == null ? void 0 : _a.toLowerCase();
    let contentType = "application/octet-stream";
    const mimeTypes = {
      "jpg": "image/jpeg",
      "jpeg": "image/jpeg",
      "png": "image/png",
      "gif": "image/gif",
      "webp": "image/webp",
      "bmp": "image/bmp",
      "svg": "image/svg+xml"
    };
    if (mimeTypes[ext]) {
      contentType = mimeTypes[ext];
    }
    setHeader(event, "Content-Type", contentType);
    setHeader(event, "Cache-Control", "public, max-age=3600");
    return buffer;
  } catch (err) {
    console.error("FTP \u56FE\u7247\u83B7\u53D6\u5931\u8D25:", err);
    throw createError({
      statusCode: 500,
      statusMessage: "\u83B7\u53D6\u56FE\u7247\u5931\u8D25"
    });
  } finally {
    client.close();
  }
});

export { ftpImage_get as default };
//# sourceMappingURL=ftp-image.get.mjs.map
