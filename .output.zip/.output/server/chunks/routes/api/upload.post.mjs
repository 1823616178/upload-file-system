import { c as defineEventHandler, i as readMultipartFormData, j as getRequestIP, k as getRequestHeader } from '../../_/nitro.mjs';
import { Client } from 'basic-ftp';
import { Readable } from 'stream';
import path from 'path';
import { p as prisma } from '../../_/db.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@prisma/client';

const ALLOWED_IMAGE_TYPES = [
  "image/jpeg",
  "image/jpg",
  "image/png",
  "image/gif",
  "image/webp",
  "image/bmp",
  "image/svg+xml"
];
const ALLOWED_EXTENSIONS = [".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".svg"];
const MAX_FILE_SIZE = 100 * 1024 * 1024;
const validateFileType = (filename, type) => {
  const ext = path.extname(filename).toLowerCase();
  const isValidExtension = ALLOWED_EXTENSIONS.includes(ext);
  const isValidMimeType = ALLOWED_IMAGE_TYPES.includes(type == null ? void 0 : type.toLowerCase());
  return isValidExtension || isValidMimeType;
};
const formatFileSize = (bytes) => {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return Math.round(bytes / Math.pow(k, i) * 100) / 100 + " " + sizes[i];
};
const getMimeType = (filename) => {
  const ext = path.extname(filename).toLowerCase();
  const mimeTypes = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".gif": "image/gif",
    ".webp": "image/webp",
    ".bmp": "image/bmp",
    ".svg": "image/svg+xml"
  };
  return mimeTypes[ext] || "application/octet-stream";
};
const upload_post = defineEventHandler(async (event) => {
  var _a;
  try {
    const formData = await readMultipartFormData(event);
    if (!formData) {
      throw new Error("\u6CA1\u6709\u63A5\u6536\u5230\u6587\u4EF6\u6570\u636E");
    }
    const file = formData.find((item) => item.name === "file");
    const remotePath = formData.find((item) => item.name === "remotePath");
    if (!file || !file.data) {
      throw new Error("\u672A\u627E\u5230\u4E0A\u4F20\u7684\u6587\u4EF6");
    }
    const fileName = file.filename || "uploaded_file";
    const fileSize = file.data ? file.data.length : 0;
    if (fileSize > MAX_FILE_SIZE) {
      throw new Error(`\u6587\u4EF6\u5927\u5C0F\u8D85\u8FC7\u9650\u5236\uFF0C\u6700\u5927\u5141\u8BB8 ${MAX_FILE_SIZE / 1024 / 1024}MB`);
    }
    if (!validateFileType(fileName, file.type)) {
      throw new Error("\u6587\u4EF6\u683C\u5F0F\u4E0D\u652F\u6301\uFF0C\u4EC5\u652F\u6301\u56FE\u7247\u683C\u5F0F\uFF1Ajpg, png, gif, webp, bmp, svg");
    }
    const remotePathStr = ((_a = remotePath == null ? void 0 : remotePath.data) == null ? void 0 : _a.toString()) || "/static/wenjinyangyi";
    const client = new Client();
    try {
      await client.access({
        host: "192.168.1.166",
        user: "userftp",
        password: "550312171",
        port: 21,
        secure: false
      });
      await client.ensureDir(remotePathStr);
      const remoteFilePath = `${remotePathStr}/${fileName}`;
      const buffer = Buffer.from(file.data);
      const stream = Readable.from(buffer);
      await client.uploadFrom(stream, remoteFilePath);
      console.log(`\u6587\u4EF6\u4E0A\u4F20\u6210\u529F: ${remoteFilePath}`);
      const ipAddress = getRequestIP(event, { xForwardedFor: true }) || "0.0.0.0";
      const userAgent = getRequestHeader(event, "user-agent") || "Unknown";
      const record = await prisma.uploadHistory.create({
        data: {
          fileName,
          fileSize: BigInt(fileSize),
          fileType: file.type || getMimeType(fileName),
          remotePath: remoteFilePath,
          uploadTime: /* @__PURE__ */ new Date(),
          ipAddress,
          userAgent
        }
      });
      console.log(`\u5386\u53F2\u8BB0\u5F55\u4FDD\u5B58\u6210\u529F\uFF0CID: ${record.id}`);
      return {
        success: true,
        message: "\u6587\u4EF6\u4E0A\u4F20\u6210\u529F",
        fileName,
        remotePath: remoteFilePath,
        fileSize,
        fileSizeFormatted: formatFileSize(fileSize),
        recordId: record.id.toString(),
        uploadTime: record.uploadTime.toISOString()
      };
    } catch (ftpError) {
      console.error("FTP\u4E0A\u4F20\u5931\u8D25:", ftpError);
      throw new Error(`FTP\u4E0A\u4F20\u5931\u8D25: ${ftpError.message}`);
    } finally {
      client.close();
    }
  } catch (error) {
    console.error("\u670D\u52A1\u5668\u9519\u8BEF:", error);
    return {
      success: false,
      error: error.message || "\u670D\u52A1\u5668\u5904\u7406\u5931\u8D25"
    };
  }
});

export { upload_post as default };
//# sourceMappingURL=upload.post.mjs.map
