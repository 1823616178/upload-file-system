import { c as defineEventHandler, g as getQuery } from '../../_/nitro.mjs';
import { Client } from 'basic-ftp';
import { p as prisma } from '../../_/db.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@prisma/client';

const history_get = defineEventHandler(async (event) => {
  try {
    const queryStr = getQuery(event);
    const page = parseInt(queryStr.page) || 1;
    const pageSize = parseInt(queryStr.pageSize) || 10;
    const search = queryStr.search || "";
    const client = new Client();
    const ftpFiles = [];
    try {
      await client.access({
        host: "192.168.1.166",
        user: "userftp",
        password: "550312171",
        port: 21,
        secure: false
      });
      const fileList = await client.list("/static/wenjinyangyi");
      console.log("FTP \u6587\u4EF6\u5217\u8868:", fileList);
      for (const file of fileList) {
        if (file.name === "." || file.name === "..") continue;
        ftpFiles.push({
          name: file.name,
          size: file.size,
          type: file.type,
          modifyTime: file.modifyTime,
          remotePath: `/static/wenjinyangyi/${file.name}`
        });
      }
    } catch (ftpError) {
      console.error("FTP \u8FDE\u63A5\u5931\u8D25:", ftpError);
    } finally {
      client.close();
    }
    let historyData = [];
    let total = 0;
    if (ftpFiles.length > 0) {
      historyData = ftpFiles.map((file) => ({
        id: Date.now() + Math.random(),
        fileName: file.name,
        fileSize: file.size,
        fileSizeFormatted: formatFileSize(file.size),
        fileType: file.type || "application/octet-stream",
        remotePath: file.remotePath,
        uploadTime: file.modifyTime ? file.modifyTime.toISOString() : (/* @__PURE__ */ new Date()).toISOString(),
        source: "ftp"
        // 标记来源为 FTP
      }));
      total = historyData.length;
    } else {
      console.log("\u4F7F\u7528\u6570\u636E\u5E93\u5386\u53F2\u8BB0\u5F55");
      const where = {};
      if (search) {
        where.fileName = {
          contains: search
        };
      }
      total = await prisma.uploadHistory.count({ where });
      const data = await prisma.uploadHistory.findMany({
        where,
        orderBy: {
          uploadTime: "desc"
        },
        skip: (page - 1) * pageSize,
        take: pageSize
      });
      historyData = data.map((item) => ({
        id: item.id.toString(),
        fileName: item.fileName,
        fileSize: Number(item.fileSize),
        fileSizeFormatted: formatFileSize(Number(item.fileSize)),
        fileType: item.fileType,
        remotePath: item.remotePath,
        ipAddress: item.ipAddress || "-",
        userAgent: item.userAgent || "-",
        uploadTime: item.uploadTime ? new Date(item.uploadTime).toISOString() : (/* @__PURE__ */ new Date()).toISOString(),
        source: "database"
        // 标记来源为数据库
      }));
    }
    const startIndex = (page - 1) * pageSize;
    const endIndex = startIndex + pageSize;
    const paginatedData = ftpFiles.length > 0 ? historyData.slice(startIndex, endIndex) : historyData;
    return {
      success: true,
      data: paginatedData,
      source: ftpFiles.length > 0 ? "ftp" : "database",
      pagination: {
        page,
        pageSize,
        total: ftpFiles.length > 0 ? ftpFiles.length : total,
        totalPages: Math.ceil((ftpFiles.length > 0 ? ftpFiles.length : total) / pageSize)
      }
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u5386\u53F2\u8BB0\u5F55\u5931\u8D25:", error);
    return {
      success: false,
      error: error.message || "\u83B7\u53D6\u5386\u53F2\u8BB0\u5F55\u5931\u8D25"
    };
  }
});
const formatFileSize = (bytes) => {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return Math.round(bytes / Math.pow(k, i) * 100) / 100 + " " + sizes[i];
};

export { history_get as default };
//# sourceMappingURL=history.get.mjs.map
