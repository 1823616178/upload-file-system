import { c as defineEventHandler, r as readBody } from '../../_/nitro.mjs';
import { Client } from 'basic-ftp';
import { p as prisma } from '../../_/db.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import '@prisma/client';

const history_delete = defineEventHandler(async (event) => {
  try {
    const body = await readBody(event);
    const { id, source, remotePath } = body;
    if (source === "ftp") {
      if (!remotePath) {
        throw new Error("FTP \u5220\u9664\u9700\u8981\u6587\u4EF6\u8DEF\u5F84");
      }
      console.log(`\u6B63\u5728\u5220\u9664 FTP \u6587\u4EF6: ${remotePath}`);
      const client = new Client();
      try {
        await client.access({
          host: "192.168.1.166",
          user: "userftp",
          password: "550312171",
          port: 21,
          secure: false
        });
        await client.remove(remotePath);
        console.log(`FTP \u6587\u4EF6\u5220\u9664\u6210\u529F: ${remotePath}`);
        try {
          await prisma.uploadHistory.deleteMany({
            where: {
              remotePath
            }
          });
          console.log("\u5173\u8054\u7684\u6570\u636E\u5E93\u8BB0\u5F55\u5DF2\u6E05\u7406");
        } catch (dbError) {
          console.warn("\u6E05\u7406\u6570\u636E\u5E93\u8BB0\u5F55\u5931\u8D25 (\u975E\u81F4\u547D):", dbError);
        }
        return {
          success: true,
          message: "\u6587\u4EF6\u5DF2\u5220\u9664"
        };
      } catch (ftpError) {
        console.error("FTP \u64CD\u4F5C\u5931\u8D25:", ftpError);
        throw new Error(`\u65E0\u6CD5\u5220\u9664 FTP \u6587\u4EF6: ${ftpError.message}`);
      } finally {
        client.close();
      }
    }
    if (!id) {
      throw new Error("\u7F3A\u5C11\u8BB0\u5F55 ID");
    }
    const idNumber = Math.floor(Number(id));
    const idBigInt = BigInt(idNumber);
    console.log(`\u5220\u9664\u6570\u636E\u5E93\u8BB0\u5F55 ID: ${idBigInt}`);
    await prisma.uploadHistory.delete({
      where: {
        id: idBigInt
      }
    });
    return {
      success: true,
      message: "\u8BB0\u5F55\u5220\u9664\u6210\u529F"
    };
  } catch (error) {
    if (error.code === "P2025") {
      return {
        success: false,
        error: "\u627E\u4E0D\u5230\u8BE5\u8BB0\u5F55"
      };
    }
    console.error("\u5220\u9664\u5904\u7406\u5931\u8D25:", error);
    return {
      success: false,
      error: error.message || "\u5220\u9664\u5931\u8D25"
    };
  }
});

export { history_delete as default };
//# sourceMappingURL=history.delete.mjs.map
