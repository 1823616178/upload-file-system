import { c as defineEventHandler, g as getQuery } from '../../_/nitro.mjs';
import { Client } from 'basic-ftp';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const ftpFile_get = defineEventHandler(async (event) => {
  try {
    const query = getQuery(event);
    const remotePath = query.path;
    if (!remotePath) {
      throw new Error("\u7F3A\u5C11\u6587\u4EF6\u8DEF\u5F84\u53C2\u6570");
    }
    const client = new Client();
    try {
      await client.access({
        host: "192.168.1.166",
        user: "userftp",
        password: "550312171",
        port: 21,
        secure: false
      });
      const lastSlashIndex = remotePath.lastIndexOf("/");
      const dirPath = lastSlashIndex !== -1 ? remotePath.substring(0, lastSlashIndex) || "/" : "/";
      const fileName = remotePath.split("/").pop();
      const fileList = await client.list(dirPath);
      const file = fileList.find((f) => f.name === fileName);
      if (!file) {
        throw new Error("\u6587\u4EF6\u4E0D\u5B58\u5728");
      }
      if (file.type === 1) {
        const files = await client.list(remotePath);
        return {
          success: true,
          isDirectory: true,
          data: {
            path: remotePath,
            files: files.map((f) => ({
              name: f.name,
              size: f.size,
              sizeFormatted: formatFileSize(f.size),
              type: f.type,
              isDirectory: f.type === 1,
              modifyTime: f.modifyTime,
              fullPath: `${remotePath}/${f.name}`.replace("//", "/")
            }))
          }
        };
      } else {
        const buffer = await client.downloadToBuffer(remotePath);
        const base64 = buffer.toString("base64");
        const mimeType = getMimeType(fileName);
        return {
          success: true,
          isDirectory: false,
          data: {
            path: remotePath,
            name: fileName,
            size: file.size,
            sizeFormatted: formatFileSize(file.size),
            type: mimeType,
            modifyTime: file.modifyTime,
            base64,
            previewUrl: `data:${mimeType};base64,${base64}`
          }
        };
      }
    } catch (ftpError) {
      console.error("FTP \u64CD\u4F5C\u5931\u8D25:", ftpError);
      throw new Error(`\u65E0\u6CD5\u8BBF\u95EE FTP \u670D\u52A1\u5668: ${ftpError.message}`);
    } finally {
      client.close();
    }
  } catch (error) {
    console.error("\u83B7\u53D6 FTP \u6587\u4EF6\u5931\u8D25:", error);
    return {
      success: false,
      error: error.message || "\u83B7\u53D6\u6587\u4EF6\u5931\u8D25"
    };
  }
});
const formatFileSize = (bytes) => {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return Math.round(bytes / Math.pow(k, i) * 100) / 100 + " " + sizes[i];
};
const getMimeType = (filename) => {
  var _a;
  const ext = (_a = filename.split(".").pop()) == null ? void 0 : _a.toLowerCase();
  const mimeTypes = {
    "jpg": "image/jpeg",
    "jpeg": "image/jpeg",
    "png": "image/png",
    "gif": "image/gif",
    "webp": "image/webp",
    "bmp": "image/bmp",
    "svg": "image/svg+xml",
    "pdf": "application/pdf",
    "txt": "text/plain",
    "json": "application/json"
  };
  return mimeTypes[ext] || "application/octet-stream";
};

export { ftpFile_get as default };
//# sourceMappingURL=ftp-file.get.mjs.map
