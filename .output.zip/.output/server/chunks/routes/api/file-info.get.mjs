import { c as defineEventHandler, g as getQuery } from '../../_/nitro.mjs';
import { Client } from 'basic-ftp';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const fileInfo_get = defineEventHandler(async (event) => {
  try {
    const query = getQuery(event);
    const remotePath = query.path || "/static/wenjinyangyi";
    const client = new Client();
    let fileList = [];
    try {
      await client.access({
        host: "192.168.1.166",
        user: "userftp",
        password: "550312171",
        port: 21,
        secure: false
      });
      const files = await client.list(remotePath);
      fileList = files.map((file) => ({
        name: file.name,
        size: file.size,
        sizeFormatted: formatFileSize(file.size),
        type: file.type,
        // 1 = directory, 2 = file, 0 = unknown
        isDirectory: file.type === 1,
        modifyTime: file.modifyTime,
        remotePath: remotePath.endsWith("/") ? `${remotePath}${file.name}` : `${remotePath}/${file.name}`,
        permissions: file.permissions
      }));
    } catch (ftpError) {
      console.error("FTP \u64CD\u4F5C\u5931\u8D25:", ftpError);
      throw new Error(`\u65E0\u6CD5\u8BBF\u95EE FTP \u670D\u52A1\u5668: ${ftpError.message}`);
    } finally {
      client.close();
    }
    return {
      success: true,
      data: fileList,
      path: remotePath,
      total: fileList.length
    };
  } catch (error) {
    console.error("\u83B7\u53D6\u6587\u4EF6\u4FE1\u606F\u5931\u8D25:", error);
    return {
      success: false,
      error: error.message || "\u83B7\u53D6\u6587\u4EF6\u4FE1\u606F\u5931\u8D25"
    };
  }
});
const formatFileSize = (bytes) => {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return Math.round(bytes / Math.pow(k, i) * 100) / 100 + " " + sizes[i];
};

export { fileInfo_get as default };
//# sourceMappingURL=file-info.get.mjs.map
