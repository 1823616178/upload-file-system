import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient({
  log: ["error", "warn"]
});
process.on("beforeExit", async () => {
  await prisma.$disconnect();
});

export { prisma as p };
//# sourceMappingURL=db.mjs.map
