import"./DJpraIdP.js";const r=""+new URL("logo-black.BD4Xi-rg.png",import.meta.url).href;export{r as _};
